package com.ponsun.cms.FilesStorage.service;


import com.ponsun.cms.FilesStorage.request.CreateFileStorageRequest;
import com.ponsun.cms.infrastructure.utils.Response;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface FileStorageWritePlatformService {
    Response createFileStorage(CreateFileStorageRequest createFileStorageRequest);

//    void documentsave(MultipartFile documentfiles, Integer cmsId,Integer PathId, Integer imgName);


//    @Transactional
//    void documentsave(List<MultipartFile> documentfiles, Integer cmsId, Integer pathId, Integer imgName);

//    void updatecompanyDocument(Integer id);

    @Transactional
    void documentsave(List<MultipartFile> documentfiles, Integer cmsId, Integer pathId, String imgName, Integer isProfileImage);

    void updatecompanyDocument(Integer cmsId , Integer  pathId , Integer documentId);


    @Transactional
    void companyEdit(List<MultipartFile> documentfiles, Integer cmsId, Integer pathId,Integer documentId, String imgName, Integer isProfileImage);
}
