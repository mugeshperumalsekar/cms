package com.ponsun.cms.details.request;

import lombok.Data;

@Data
public class CreateDetailsRequest extends AbstractDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
