package com.ponsun.cms.allDetails.address.request;

import lombok.Data;

@Data
public class CreateAddressRequest extends AbstractAddressRequest {
    @Override
    public String toString(){ return super.toString();}
}
