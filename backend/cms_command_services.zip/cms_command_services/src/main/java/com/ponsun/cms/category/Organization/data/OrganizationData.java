package com.ponsun.cms.category.Organization.data;

import lombok.Data;

@Data
public class OrganizationData {
    private Integer cmsId;
    private String userName;
    private String cmsName;
    private String sourceLink;
    private Integer genderId;

    public OrganizationData(final Integer cmsId , String userName, final String cmsName , final String sourceLink , final Integer genderId) {
        this.cmsId = cmsId;
        this.userName = userName;
        this.cmsName = cmsName;
        this.sourceLink = sourceLink;
        this.genderId = genderId;
    }

    public static OrganizationData newInstance (final Integer cmsId , String userName, final String cmsName , final String sourceLink , final Integer genderId) {
        return new OrganizationData(cmsId,userName, cmsName, sourceLink, genderId);
    }
}
