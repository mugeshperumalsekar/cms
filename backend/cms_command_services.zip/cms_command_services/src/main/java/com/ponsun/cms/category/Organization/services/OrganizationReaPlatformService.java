package com.ponsun.cms.category.Organization.services;


import com.ponsun.cms.category.Organization.data.OrganizationData;

import java.util.List;

public interface OrganizationReaPlatformService {
    List<OrganizationData> fetchAllOrganizationData(String cmsName);
}
