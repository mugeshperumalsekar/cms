package com.ponsun.cms.FilesStorage.request;

public class UpdateFileStorageRequest {
    @Override
    public String toString() {
        return super.toString();
    }



//    public Object getName() {
//    }
}
