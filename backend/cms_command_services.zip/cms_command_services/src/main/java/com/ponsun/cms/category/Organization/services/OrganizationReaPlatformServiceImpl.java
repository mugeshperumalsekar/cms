package com.ponsun.cms.category.Organization.services;


import com.ponsun.cms.category.Organization.data.OrganizationData;
import com.ponsun.cms.category.Organization.rowmapper.OrganizationRowMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor

public class OrganizationReaPlatformServiceImpl implements OrganizationReaPlatformService {

    private final OrganizationRowMapper organizationRowMapper;
    private final JdbcTemplate jdbcTemplate;

    @Override
    public List<OrganizationData> fetchAllOrganizationData(String cmsName ) {
        final OrganizationRowMapper rowMapper = new OrganizationRowMapper();
        String Qry = "SELECT " + rowMapper.tableSchema();
        String whereClause = "  WHERE a.uid=c.id AND a.status = 'A' AND b.id = a.recordTypeId AND b.id= 5 AND a.name = ?";
        Qry = Qry + whereClause;
        final List<OrganizationData> organizationData = jdbcTemplate.query(Qry, organizationRowMapper,
                new Object[]{cmsName}
        );
        return organizationData;
    }
}



