package com.ponsun.cms.IndOrg.positions.request;

public class UpdatePositionsRequest extends AbstractPositionsRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}