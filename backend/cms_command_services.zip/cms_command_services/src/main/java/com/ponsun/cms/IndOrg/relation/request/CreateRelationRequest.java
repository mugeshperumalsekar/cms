package com.ponsun.cms.IndOrg.relation.request;

import lombok.Data;

@Data
public class CreateRelationRequest extends AbstractRelationRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
