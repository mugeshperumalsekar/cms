package com.ponsun.cms.company.companyAliases.request;

import lombok.Data;

@Data
public class UpdateCompanyAliasesRequest extends AbstractCompanyAliasesRequest {
    @Override
    public String toString(){ return super.toString();}
}
