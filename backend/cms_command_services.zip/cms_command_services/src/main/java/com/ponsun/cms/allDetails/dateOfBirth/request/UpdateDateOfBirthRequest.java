package com.ponsun.cms.allDetails.dateOfBirth.request;

import lombok.Data;

@Data
public class UpdateDateOfBirthRequest extends AbstractDateOfBirthRequest {
    @Override
    public String toString(){ return super.toString();}
}
