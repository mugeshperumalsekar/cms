package com.ponsun.cms.caseDetails.request;

import lombok.Data;

@Data
public class UpdateCaseDetailsRequest extends AbstractCaseDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
