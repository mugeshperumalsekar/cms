package com.ponsun.cms.allDetails.dateOfBirth.request;

import lombok.Data;

@Data
public class CreateDateOfBirthRequest extends AbstractDateOfBirthRequest {
    @Override
    public String toString(){ return super.toString();}
}
