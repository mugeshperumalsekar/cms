package com.ponsun.cms.IndOrg.relationAliases.request;

import lombok.Data;

@Data
public class UpdateRelationAliasesRequest extends AbstractRelationAliasesRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
