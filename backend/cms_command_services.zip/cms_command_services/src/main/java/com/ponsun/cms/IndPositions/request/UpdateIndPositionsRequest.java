package com.ponsun.cms.IndPositions.request;

import lombok.Data;

@Data
public class UpdateIndPositionsRequest extends AbstractIndPositionsRequest {
    public String toString() {
        return super.toString();
    }
}
