package com.ponsun.cms.adminconfiguration.AdminUser.request;

import lombok.Data;

@Data
public class CreateUserRequest extends AbstractUserBaseRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}

