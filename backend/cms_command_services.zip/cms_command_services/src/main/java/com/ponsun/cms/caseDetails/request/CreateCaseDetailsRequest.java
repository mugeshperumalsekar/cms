package com.ponsun.cms.caseDetails.request;

import lombok.Data;

@Data
public class CreateCaseDetailsRequest  extends AbstractCaseDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
