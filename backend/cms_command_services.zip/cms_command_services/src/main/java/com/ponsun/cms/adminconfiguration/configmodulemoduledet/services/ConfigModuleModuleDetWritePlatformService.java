package com.ponsun.cms.adminconfiguration.configmodulemoduledet.services;



import com.ponsun.cms.adminconfiguration.configmodulemoduledet.data.ConfigModuleModuleDetData;

import java.util.List;

public interface ConfigModuleModuleDetWritePlatformService {
    List<ConfigModuleModuleDetData> fetchAllListofAlertData();
}
