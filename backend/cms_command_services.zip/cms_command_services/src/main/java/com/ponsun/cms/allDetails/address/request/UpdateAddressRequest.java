package com.ponsun.cms.allDetails.address.request;

public class UpdateAddressRequest extends AbstractAddressRequest {
    @Override
    public String toString(){ return super.toString();}
}
