package com.ponsun.cms.company.companyDetails.request;

import lombok.Data;

@Data
public class CreateCompanyDetailsRequest extends AbstractCompanyDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
