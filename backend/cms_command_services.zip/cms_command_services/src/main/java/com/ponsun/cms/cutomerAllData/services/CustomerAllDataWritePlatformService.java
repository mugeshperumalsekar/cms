package com.ponsun.cms.cutomerAllData.services;



import com.ponsun.cms.cutomerAllData.data.CustomerAllDataData;

import java.util.List;

public interface CustomerAllDataWritePlatformService {
    List<CustomerAllDataData> fetchAllCustomerData();
}
