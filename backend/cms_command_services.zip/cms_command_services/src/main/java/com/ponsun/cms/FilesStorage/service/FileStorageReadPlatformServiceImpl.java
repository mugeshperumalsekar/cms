package com.ponsun.cms.FilesStorage.service;

public class FileStorageReadPlatformServiceImpl implements FileStorageReadPlatformService {

}
