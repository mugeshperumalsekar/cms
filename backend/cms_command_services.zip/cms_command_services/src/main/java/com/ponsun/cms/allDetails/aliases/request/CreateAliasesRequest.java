package com.ponsun.cms.allDetails.aliases.request;

import lombok.Data;

@Data
public class CreateAliasesRequest extends AbstractAliasesRequest {
    @Override
    public String toString() { return super.toString();}
}
