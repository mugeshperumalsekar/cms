package com.ponsun.cms.company.companyAliases.request;

import lombok.Data;

@Data

public class CreateCompanyAliasesRequest extends AbstractCompanyAliasesRequest {
    @Override
    public String toString(){ return super.toString();}
}