package com.ponsun.cms.IndOrg.positions.request;

public class CreatePositionsRequest extends AbstractPositionsRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
