package com.ponsun.cms.category.Organization.api;

import com.ponsun.cms.category.Organization.data.OrganizationData;
import com.ponsun.cms.category.Organization.services.OrganizationReaPlatformService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("api/v1/Organization")
public class OrganizationApiResource {
    private  final OrganizationReaPlatformService organizationReaPlatformService;
    @GetMapping
    public List<OrganizationData> fetchAll(String cmsName ){
        return this.organizationReaPlatformService.fetchAllOrganizationData(cmsName);}
}
