package com.ponsun.cms.IndOrg.indAliasesName.request;

public class UpdateIndAliasesNameRequest extends AbstractIndAliasesNameRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}