package com.ponsun.cms.FilesStorage.api;


import com.ponsun.cms.FilesStorage.service.FileDownloadUtil;
import com.ponsun.cms.FilesStorage.service.FileStorageWritePlatformService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@Slf4j
@RequiredArgsConstructor
@RequestMapping("api/v1/Document")
@Tag(name = "DocumentApiResource")
public class FileStorageApiResource {

    private final FileStorageWritePlatformService fileStorageWritePlatformService;
    private final JdbcTemplate jdbcTemplate;


    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadFiles(
            @RequestPart(value = "files") MultipartFile[] files,
            @RequestParam(value = "cmsId") Integer cmsId,
            @RequestParam(value = "pathId") Integer[] pathIds,
            @RequestParam(value = "documentId") Integer[] documentIds,
            @RequestParam(value = "imgName") String imgName,
            @RequestParam(value = "isProfileImage") Integer isProfileImage

    ) {
        if (files == null || files.length == 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No files uploaded. Please attach files.");
        }

        if (pathIds.length != files.length || documentIds.length != files.length) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Mismatched array sizes for pathId and documentId.");
        }

        List<String> messages = new ArrayList<>();
        try {
            for (int j = 0; j < files.length; j++) {
                MultipartFile file = files[j];
                if (file.isEmpty()) {
                    messages.add("Skipping empty file at index " + j);
                    continue;
                }

                fileStorageWritePlatformService.companyEdit(
                        List.of(file), // Convert to List
                        cmsId,
                        pathIds[j],
                        documentIds[j],
                        imgName,
                        isProfileImage
                );
                messages.add(file.getOriginalFilename() + " [Successful]");
            }
            return ResponseEntity.ok("Files uploaded successfully");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload files: " + e.getMessage());
        }
    }





    @GetMapping("/downloadDocument/{cmsId}/{pathId}")
    public ResponseEntity<?> downloadDocument(@PathVariable("cmsId") Integer cmsId, @PathVariable("pathId") Integer pathId,Integer isProfileImage) {
        FileDownloadUtil downloadUtil = new FileDownloadUtil();

        String sql = "SELECT id ,CONCAT(id, '.', documentType) AS concatenated_name FROM cms_document WHERE cmsId = ? AND pathId = ? AND  isProfileImage=? AND STATUS='A'";

        List<String> fileNames = jdbcTemplate.query(sql, new Object[]{cmsId, pathId,isProfileImage}, (resultSet, rowNum) ->
                resultSet.getString("concatenated_name"));

        List<ResponseEntity<Resource>> responses = new ArrayList<>();

        System.out.println("fileNames:" + fileNames);
        for (String fileName : fileNames) {
            System.out.println("fileName:" + fileName);
            Resource resource = null;
            try {
                resource = downloadUtil.documentList(cmsId, pathId, fileName);
            } catch (IOException e) {
                System.err.println("Error loading file: " + fileName);
                e.printStackTrace();
                return ResponseEntity.internalServerError().build();
            }

            if (resource == null) {
                System.err.println("File not found: " + fileName);
                continue;
            }

            String contentType = "application/octet-stream";
            String headerValue = "attachment; filename=\"" + resource.getFilename() + "\"";

            responses.add(ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
                    .body(resource));
        }

        if (responses.isEmpty()) {
            return new ResponseEntity<>("No valid documents found", HttpStatus.NOT_FOUND);
        } else {

            return responses.get(0);
        }
    }


    // API to download an individual file using fileId
    @GetMapping("/downloadFile/{cmsId}")
    public ResponseEntity<?> getFileDownloadLinks(@PathVariable("cmsId") Integer cmsId) {
        String sql = "SELECT id, documentType, url,isProfileImage FROM cms_document WHERE cmsId = ? AND STATUS = 'A'";

        List<Map<String, String>> fileDetails = jdbcTemplate.query(sql, new Object[]{cmsId}, (resultSet, rowNum) -> {
            Map<String, String> fileInfo = new HashMap<>();
            fileInfo.put("fileId", resultSet.getString("id"));
            fileInfo.put("fileName", resultSet.getString("id") + "." + resultSet.getString("documentType"));
            fileInfo.put("documentType", resultSet.getString("documentType"));
            fileInfo.put("isProfileImage", resultSet.getString("isProfileImage"));



            return fileInfo;
        });

        if (fileDetails.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No valid documents found for cmsId: " + cmsId);
        }

        return ResponseEntity.ok(fileDetails);
    }
    @GetMapping("/downloadSingleFile/{fileId}")
    public ResponseEntity<Resource> downloadSingleFile(@PathVariable("fileId") Integer fileId) throws IOException {
        String sql = "SELECT id, documentType, url FROM cms_document WHERE id = ? AND STATUS = 'A'";

        List<Map<String, String>> fileData = jdbcTemplate.query(sql, new Object[]{fileId}, (resultSet, rowNum) -> {
            Map<String, String> fileInfo = new HashMap<>();
            fileInfo.put("filePath", resultSet.getString("url") + "\\" + resultSet.getString("id") + "." + resultSet.getString("documentType"));
            fileInfo.put("fileName", resultSet.getString("id") + "." + resultSet.getString("documentType"));
            return fileInfo;
        });

        if (fileData.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        String filePath = fileData.get(0).get("filePath");
        File file = new File(filePath);

        if (!file.exists()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        Resource resource = new FileSystemResource(file);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileData.get(0).get("fileName") + "\"")
                .contentType(org.springframework.http.MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }


}



