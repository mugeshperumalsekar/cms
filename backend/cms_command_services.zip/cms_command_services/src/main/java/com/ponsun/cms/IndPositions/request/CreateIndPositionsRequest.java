package com.ponsun.cms.IndPositions.request;

import lombok.Data;

@Data
public class CreateIndPositionsRequest extends AbstractIndPositionsRequest {
    public String toString() {
        return super.toString();
    }
}
