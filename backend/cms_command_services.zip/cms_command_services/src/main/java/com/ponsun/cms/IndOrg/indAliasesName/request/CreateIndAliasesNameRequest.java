package com.ponsun.cms.IndOrg.indAliasesName.request;

public class CreateIndAliasesNameRequest extends AbstractIndAliasesNameRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
