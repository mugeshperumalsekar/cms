package com.ponsun.cms.adminconfiguration.adminuserauthority.request;

public class UpdateAdminUserAuthorityRequest extends AbstractAdminUserAuthorityBaseRequest {
    @Override
    public String toString() {return super.toString();}
}