package com.ponsun.cms.adminconfiguration.adminuserrights.request;

import lombok.Data;

@Data
public class UpdateAdminUserRightsRequest extends AbstractAdminUserRightsBaseRequest{

    @Override

    public String toString() {
        return super.toString();
    }

}