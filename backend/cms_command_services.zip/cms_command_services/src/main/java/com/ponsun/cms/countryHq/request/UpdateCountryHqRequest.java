package com.ponsun.cms.countryHq.request;

public class UpdateCountryHqRequest extends AbstractCountryHqRequest {
    @Override
    public String toString(){ return super.toString();}
}