package com.ponsun.cms.FilesStorage.data;

public class FileStorageDataValidator {
}
