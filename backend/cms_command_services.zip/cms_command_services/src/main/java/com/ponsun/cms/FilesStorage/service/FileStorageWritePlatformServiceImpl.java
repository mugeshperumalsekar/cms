package com.ponsun.cms.FilesStorage.service;


import com.ponsun.cms.FilesStorage.domain.FileStorage;
import com.ponsun.cms.FilesStorage.domain.FileStorageRepository;
import com.ponsun.cms.FilesStorage.request.CreateFileStorageRequest;
import com.ponsun.cms.infrastructure.exceptions.EQAS_CMS_ApplicationException;
import com.ponsun.cms.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileStorageWritePlatformServiceImpl implements FileStorageWritePlatformService {
    private final JdbcTemplate jdbcTemplate;
    private final FileStorageRepository fileStorageRepository;

    private final String baseRoot = "D:\\uploadImages";

    @Override
    @Transactional
    public Response createFileStorage(CreateFileStorageRequest createFileStorageRequest) {
        try{
            final FileStorage fileStorage = FileStorage.create(createFileStorageRequest);
            this.fileStorageRepository.saveAndFlush(fileStorage);
            return Response.of(fileStorage.getId());
        }catch (DataIntegrityViolationException e){
            throw new EQAS_CMS_ApplicationException(e.getMessage());
        }
    }


    @Override
    @Transactional
    public void documentsave(List<MultipartFile> documentfiles, Integer cmsId, Integer pathId, String imgName, Integer isProfileImage) {
        // Check if isProfileImage is null or 1 (true), otherwise treat it as 0 (false)
        boolean profileImageFlag = (isProfileImage != null && isProfileImage == 1);

        // Determine root directory based on profile image flag
        //String resolvedRootDirectory = profileImageFlag ? "profile_images" : getDocumentDirectory(pathId);
        String resolvedRootDirectory = isProfileImage != null && isProfileImage == 1 ? "profile_images" : getDocumentDirectory(pathId);
        System.out.println("Received isProfileImage: " + isProfileImage);
        Path root = Paths.get(baseRoot, resolvedRootDirectory);

        try {
            int documentId = getLatestDocumentId();

            String folderName = cmsId.toString();
            Path folderPath = root.resolve(folderName);
            Files.createDirectories(folderPath);
            System.out.println("Folder created at: " + folderPath);

            for (MultipartFile file : documentfiles) {
                String fileExtension = getFileExtension(file);
                System.out.println("Processing file with extension: " + fileExtension);
                Integer isProfileImageForFile = file.getOriginalFilename().equals(imgName) ? 1 : 0;

                // Create storage request
                CreateFileStorageRequest createFileStorageRequest = new CreateFileStorageRequest();
                createFileStorageRequest.setCmsId(cmsId);
                createFileStorageRequest.setDocumentId(documentId);
                createFileStorageRequest.setPathId(pathId);
                createFileStorageRequest.setDocumentType(fileExtension);
                createFileStorageRequest.setUid(1);
                createFileStorageRequest.setUrl(folderPath.toString());
                createFileStorageRequest.setIsProfileImage(isProfileImageForFile); // ✅ Correctly assigned

                // Store file entry in database
                Response response = createFileStorage(createFileStorageRequest);
                Integer imageId = (Integer) response.getId();

                // Save file with imageId as filename
                String filename = imageId + "." + fileExtension;
                Files.copy(file.getInputStream(), folderPath.resolve(filename));

                documentId++; // Increment documentId for next file
            }
        } catch (IOException e) {
            throw new RuntimeException("Error saving file", e);
        }
    }

    // Helper method to get the document storage directory
    private String getDocumentDirectory(Integer pathId) {
        switch (pathId) {
            case 1: return "document/Entity";
            case 2: return "document/Individual";
            case 3: return "document/Ship";
            case 4: return "document/Aircraft";
            case 5: return "document/Organization";
            default: throw new IllegalArgumentException("Invalid PathId");
        }
    }

    // Helper method to extract file extension
    private String getFileExtension(MultipartFile file) {
        return file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
    }

    public int getLatestDocumentId() {
        Integer latestId = jdbcTemplate.queryForObject("SELECT COALESCE(MAX(documentId), 0) FROM cms_document", Integer.class);
        return (latestId != null) ? latestId + 1 : 1;
    }


    @Override
    public void updatecompanyDocument(Integer cmsId, Integer pathId , Integer documentId) {
        try {
            String sql = "UPDATE cms_document SET status = 'D', updated_at = NOW() WHERE cmsId = ? AND pathId = ? AND documentId = ? AND status = 'A'";
            int rowsUpdated = jdbcTemplate.update(sql, cmsId, pathId , documentId);

            System.out.println("Update Query Executed for cmsId: " + cmsId + ", pathId: " + pathId);
            System.out.println("Rows affected: " + rowsUpdated);

            if (rowsUpdated == 0) {
                System.out.println("No rows updated. Possible reasons: No matching rows found or incorrect column names.");
            }

        } catch (DataAccessException e) {
            System.err.println("Error updating the document: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    @Transactional
    public void companyEdit(List<MultipartFile> documentfiles, Integer cmsId, Integer pathId, Integer documentId, String imgName, Integer isProfileImage) {

        boolean profileImageFlag = (isProfileImage != null && isProfileImage == 1);

        String resolvedRootDirectory = isProfileImage != null && isProfileImage == 1 ? "profile_images" : getDocumentDirectory(pathId);
        System.out.println("Received isProfileImage: " + isProfileImage);
        Path root = Paths.get(baseRoot, resolvedRootDirectory);
        updatecompanyDocument(cmsId, pathId , documentId);

        try {
            int latestDocumentId = getLatestDocumentId(); // ✅ Renamed variable to avoid conflict

            String folderName = cmsId.toString();
            Path folderPath = root.resolve(folderName);
            Files.createDirectories(folderPath);
            System.out.println("Folder created at: " + folderPath);

            for (MultipartFile file : documentfiles) {
                String fileExtension = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
                System.out.println("Processing file with extension: " + fileExtension);
                Integer isProfileImageForFile = profileImageFlag ? 1 : (file.getOriginalFilename().equals(imgName) ? 1 : 0);

                // Create storage request for each file
                CreateFileStorageRequest createFileStorageRequest = new CreateFileStorageRequest();
                createFileStorageRequest.setCmsId(cmsId);
                createFileStorageRequest.setDocumentId(latestDocumentId); // ✅ Using renamed variable
                createFileStorageRequest.setPathId(pathId);
                createFileStorageRequest.setDocumentType(fileExtension);
                createFileStorageRequest.setUid(1);
                createFileStorageRequest.setUrl(folderPath.toString());
                createFileStorageRequest.setIsProfileImage(isProfileImageForFile); // ✅ Correctly assigned

                System.out.println("Final isProfileImage for DB: " + createFileStorageRequest.getIsProfileImage());

                // Store file entry in the database
                Response response = createFileStorage(createFileStorageRequest);
                Integer imageId = (Integer) response.getId();

                // Save file with documentId as filename
                String filename = imageId + "." + fileExtension;
                Files.copy(file.getInputStream(), folderPath.resolve(filename));

                latestDocumentId++; // ✅ Increment the correct variable
            }
        } catch (NullPointerException e) {
            throw new RuntimeException("File storage service is currently unavailable. Please try again later.");
        } catch (IOException e) {
            throw new RuntimeException("Error saving file", e);
        }
    }


    public String getProfileImage(Integer cmsId) {
        String sql = "SELECT url FROM cms_document WHERE cmsId = ? AND is_profile_image = true";
        return jdbcTemplate.queryForObject(sql, new Object[]{cmsId}, String.class);
    }

}

