touch .gitignore

cd existing_repo
git remote add origin https://gitlab.com/pep_services/pep_command_services.git
git branch -M main
git push -uf origin main
