import React from 'react'

export default function Individual() {
  return (
    <div>Individual</div>
  )
}