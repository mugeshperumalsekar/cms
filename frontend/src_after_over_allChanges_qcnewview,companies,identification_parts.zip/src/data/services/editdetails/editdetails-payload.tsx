export interface CompanyDocumentsData {

}