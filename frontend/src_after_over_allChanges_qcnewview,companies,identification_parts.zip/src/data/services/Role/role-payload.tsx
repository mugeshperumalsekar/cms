export interface RolePayload {
    roleName: string;
    uid: string;
}