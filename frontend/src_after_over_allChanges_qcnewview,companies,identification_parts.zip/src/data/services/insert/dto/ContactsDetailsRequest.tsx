interface ContactsDetailsRequest {
  communicationDt: String,
  communicationTypeId: String
}

export default ContactsDetailsRequest;