export interface AdmingroupPayload {
  name: string;
  moduleUrl: String;
}