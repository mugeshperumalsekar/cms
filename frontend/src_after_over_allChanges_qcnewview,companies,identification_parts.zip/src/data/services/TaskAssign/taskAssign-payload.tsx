export interface TaskAssignPayload {
    assignTo: Number;
    assignBy: Number;
    countryId: Number;
    stateId: Number;
    year: Number;
    uid: Number;
}