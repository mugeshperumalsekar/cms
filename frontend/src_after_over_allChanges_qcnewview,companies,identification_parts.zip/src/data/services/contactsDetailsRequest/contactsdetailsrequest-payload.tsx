export interface ContactsDetailsRequestPayload {
    pepId: string;
    communicationDt: string;
    communicationTypeId: string;
}