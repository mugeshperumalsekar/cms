export const CLEAR_LOGIN_DETAILS = 'CLEAR_LOGIN_DETAILS';

export const clearLoginDetails = () => {
  return {
    type: CLEAR_LOGIN_DETAILS,
  };
};