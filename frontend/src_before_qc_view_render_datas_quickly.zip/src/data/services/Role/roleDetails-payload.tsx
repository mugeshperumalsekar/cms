export interface RoleDetailsPayload {
    roleId: number;
    modId: number;
    modDetId: number;
    uid: number;
}