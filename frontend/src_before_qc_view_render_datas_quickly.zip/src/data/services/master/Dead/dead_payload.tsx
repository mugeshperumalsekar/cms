export interface DeadPayload {
  id: string;
  name: string;
}