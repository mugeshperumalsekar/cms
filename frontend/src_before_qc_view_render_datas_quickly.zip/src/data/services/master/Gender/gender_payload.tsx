export interface GenderPayload {
  id: number;
  gender: string;
}