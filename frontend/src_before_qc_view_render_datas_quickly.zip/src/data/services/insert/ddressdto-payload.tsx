export interface CompanyDocumentsData {
  id: number;
  companyId: number;
  pathId: number;
  url: String;
  documentType: String;
  documentCount: number;
  uid: number;
}