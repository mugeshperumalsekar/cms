export interface searchIdentify {
    uid: number;
    countryName: string;
    stateName: string;
    year: string;
    manName: string;
    taskId: number;
    countryId: number;
    stateId: number;
    assignById: number;
}